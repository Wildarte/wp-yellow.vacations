<div class="control_posts container">
    <?php

    the_posts_pagination( 'mid_size=3' );

    ?>
</div>